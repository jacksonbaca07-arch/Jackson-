const form = document.getElementById("chatForm");
const input = document.getElementById("message");
const messages = document.getElementById("messages");
const status = document.getElementById("status");

function addMessage(text, who) {
  const div = document.createElement("div");
  div.className = `bubble ${who}`;
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

fetch("/api/status")
  .then(r => r.json())
  .then(() => status.textContent = "● En línea")
  .catch(() => status.textContent = "● Sin conexión");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;

  addMessage(text, "user");
  input.value = "";
  input.disabled = true;

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message: text})
    });
    const data = await response.json();
    addMessage(data.reply || "No pude responder.", "roki");
  } catch {
    addMessage("No pude conectar con el servidor.", "roki");
  } finally {
    input.disabled = false;
    input.focus();
  }
});
