# Roki App

Aplicación web progresiva de Roki.

## Ejecutar
```bash
npm install
npm start
```

Luego abre http://localhost:3000

## Render
Usa:
- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`

El siguiente paso será conectar `/api/chat` a un modelo de IA real y después empaquetar Roki para Android/Play Store.
