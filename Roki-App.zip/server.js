const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (req, res) => {
  res.json({ ok: true, message: "Roki está funcionando 🚀" });
});

app.post("/api/chat", (req, res) => {
  const message = String(req.body?.message || "").trim();

  if (!message) {
    return res.status(400).json({ error: "Escribe un mensaje." });
  }

  // Respuesta inicial. Después conectaremos aquí el modelo de IA.
  res.json({
    reply: `Hola 👋 Soy Roki. Recibí tu mensaje: "${message}"`,
  });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Roki iniciado en el puerto ${PORT}`);
});
