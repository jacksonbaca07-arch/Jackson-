const http = require("http");

const PORT = process.env.PORT || 10000;

const server = http.createServer((req, res) => {
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Access-Control-Allow-Origin", "*");

  if (req.method === "GET" && req.url === "/") {
    res.writeHead(200);
    res.end(JSON.stringify({
      ok: true,
      mensaje: "Roki está funcionando 🚀"
    }));
    return;
  }

  if (req.method === "GET" && req.url === "/salud") {
    res.writeHead(200);
    res.end(JSON.stringify({ estado: "activo" }));
    return;
  }

  res.writeHead(404);
  res.end(JSON.stringify({ error: "Ruta no encontrada" }));
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Roki servidor escuchando en el puerto ${PORT}`);
});
